package com.example.smartparking

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View

class OnBoarding1 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_on_boarding1)
    }

    fun back(view: View) {}
    fun basementparking(view: View) {}
    fun back1(view: View) {}
    fun basementparking4(view: View) {}
    fun basementparking2(view: View) {}
    fun lobbyparking(view: View) {}
    fun parkparking(view: View) {}
    fun groundparking(view: View) {}
    fun basementparking3(view: View) {}
    fun detailscard(view: View) {}
}